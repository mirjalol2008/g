import requests
from config import ANILIST_CLIENT_ID

def get_anime_info(anime_name: str):
    url = 'https://graphql.anilist.co'
    query = '''
    query ($search: String) {
      Media(search: $search, type: ANIME) {
        id
        title {
          romaji
          english
          native
        }
        averageScore
        popularity
      }
    }
    '''
    variables = {'search': anime_name}
    headers = {'Authorization': f'Bearer {ANILIST_CLIENT_ID}'}
    response = requests.post(url, json={'query': query, 'variables': variables}, headers=headers)
    data = response.json()
    if 'data' in data and data['data']['Media']:
        media = data['data']['Media']
        title = media['title']['english'] or media['title']['romaji'] or media['title']['native']
        return {'id': media['id'], 'title': title, 'score': media['averageScore'], 'popularity': media['popularity']}
    return None
