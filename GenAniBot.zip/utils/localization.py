import json
import os
from database import cursor

# Load language strings
with open(os.path.join('data', 'languages.json'), 'r', encoding='utf-8') as f:
    STRINGS = json.load(f)

def get_user_language(user_id):
    cursor.execute("SELECT language_code FROM users WHERE id=%s", (user_id,))
    row = cursor.fetchone()
    return row[0] if row else 'en'

def get_string(user_id, key):
    lang = get_user_language(user_id)
    return STRINGS.get(lang, {}).get(key, key)
