import logging
from aiogram import Bot, Dispatcher, types
from aiogram.utils import executor
from config import BOT_TOKEN
from database import create_tables
from handlers import register_start, register_watchlist, register_search, register_feedback, register_language, register_admin

logging.basicConfig(level=logging.INFO)

bot = Bot(token=BOT_TOKEN, parse_mode=types.ParseMode.HTML)
dp = Dispatcher(bot)

async def on_startup(dp):
    create_tables()
    logging.info("Database tables created.")
    # Register handlers
    register_start(dp)
    register_watchlist(dp)
    register_search(dp)
    register_feedback(dp)
    register_language(dp)
    register_admin(dp)
    logging.info("Handlers registered. Bot is ready.")

if __name__ == '__main__':
    executor.start_polling(dp, on_startup=on_startup)
