from .start import register_handlers as register_start
from .watchlist import register_handlers as register_watchlist
from .search import register_handlers as register_search
from .feedback import register_handlers as register_feedback
from .language import register_handlers as register_language
from .admin import register_handlers as register_admin
