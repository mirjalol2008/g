import psycopg2
from config import DB_NAME, DB_USER, DB_PASS, DB_HOST, DB_PORT

conn = psycopg2.connect(
    dbname=DB_NAME,
    user=DB_USER,
    password=DB_PASS,
    host=DB_HOST,
    port=DB_PORT
)
cursor = conn.cursor()

def create_tables():
    cursor.execute("""
    CREATE TABLE IF NOT EXISTS users (
        id BIGINT PRIMARY KEY,
        first_name TEXT,
        language_code TEXT DEFAULT 'en'
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS watchlist (
        user_id BIGINT,
        anime_id INT,
        anime_title TEXT,
        PRIMARY KEY (user_id, anime_id)
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS feedback (
        id SERIAL PRIMARY KEY,
        user_id BIGINT,
        message TEXT,
        created_at TIMESTAMP DEFAULT NOW()
    );
    """)

    cursor.execute("""
    CREATE TABLE IF NOT EXISTS subscriptions (
        user_id BIGINT PRIMARY KEY,
        subscribed BOOLEAN DEFAULT FALSE
    );
    """)

    conn.commit()
