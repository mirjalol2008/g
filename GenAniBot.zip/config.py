BOT_TOKEN = "YOUR_BOT_TOKEN_HERE"

# PostgreSQL settings
DB_NAME = "mirjalol_postgre"
DB_USER = "mirjalol"
DB_PASS = "YOUR_DB_PASSWORD"
DB_HOST = "postgresql-mirjalol.alwaysdata.net"
DB_PORT = 5432

# AniList API
ANILIST_CLIENT_ID = "fp.661def58-757e-4dc8-9be8-594170bfacad"
